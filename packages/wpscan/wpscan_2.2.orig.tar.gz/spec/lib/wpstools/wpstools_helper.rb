# encoding: UTF-8

require 'spec_helper'

require WPSTOOLS_LIB_DIR + '/wpstools_helper'

