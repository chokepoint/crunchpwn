---
config:
  app_name: joomla-cms
  check_file: plugins/editors/tinymce/jscripts/tiny_mce/tiny_mce_src.js
sigs:
  1.7-3-Stable-Ember: b96023ce76555ad4a333f11127790dac
  1.7-3-Stable-Ember: 2d1e2b6424e991ef6072a395e75688dd
  1.7-3-Stable-Ember: 31b22dfaff36dd2f107fc4aac302345d
  1.7-3-Stable-Ember: dc7bc5a8f98948f48007e06435b66b41
  1.7-3-Stable-Ember: 2192024b0458177a7bb7196834f56049
  1.7-3-Stable-Ember: 4828b6bd8ab0419e89f29f2c70bd3440
  1.7-3-Stable-Ember: 6c8b915da5159be39e7c72c555781077
  1.7-3-Stable-Ember: 173ae0dbd3a1c26e504572a45abb276d
  1.7-3-Stable-Ember: 831af0e2e91acc955f01bee644f1bee6
  1.7-3-Stable-Ember: 2a996b66f7a1e4f2ab591c06c5bb31e5
  1.7-3-Stable-Ember: feb407f856477d61673928cb9e8731e0
  1.7-3-Stable-Ember: fd286f06e6c78e89ef7266a5e05b1db4
  1.7-3-Stable-Ember: c65a62862209f9b8d6527aae613a211a
  1.7-3-Stable-Ember: 6908ae6ee4665351782d2f3f61b2db8f
  1.7-3-Stable-Ember: 2192024b0458177a7bb7196834f56049
  1.7-3-Stable-Ember: 1a3c7082dbdc4b72906d73e022941a03
  1.7-3-Stable-Ember: feb407f856477d61673928cb9e8731e0
  1.7-3-Stable-Ember: 11d987c80589f11fe49af0d39f5bfb18
  1.7-3-Stable-Ember: 0a468b516e10737358ca9cca657462f1
