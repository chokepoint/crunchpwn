---
config:
  app_name: joomla-cms
  check_file: plugins/editors/tinymce/jscripts/tiny_mce/utils/form_utils.js
sigs:
  1.7-3-Stable-Ember: 1d61accf9e0dbeb5340e7f6e0609d9eb
  1.7-3-Stable-Ember: 950d229c37a570fc26a13da71d73f9b8
  1.7-3-Stable-Ember: fd7f6263d633369cfab4df9185073f90
  1.7-3-Stable-Ember: eb6afc37a525600e1c69f5666ab36bf5
  1.7-3-Stable-Ember: eb6afc37a525600e1c69f5666ab36bf5
  1.7-3-Stable-Ember: f1c0d47571e88874038159b980bba2fa
  1.7-3-Stable-Ember: e383d84a698118c897d4bd56ca730264
  1.7-3-Stable-Ember: dfd2287b76c0dc5f2318662c6472401c
  1.7-3-Stable-Ember: 1d821fc85c5dbeefb489590eb74ad4c3
  1.7-3-Stable-Ember: d244178eded4081ceb794a3b51f5bbbe
  1.7-3-Stable-Ember: 8c3910516f560ab1c06e69a7451f9400
  1.7-3-Stable-Ember: 0352d231bb1471e8f7ab8db859497d02
  1.7-3-Stable-Ember: dfd2287b76c0dc5f2318662c6472401c
  1.7-3-Stable-Ember: e8f3a85283227c3c152e54b86ef2491f
  1.7-3-Stable-Ember: e0ba7b41e6c87cbcbce67942b2552871
  1.7-3-Stable-Ember: d244178eded4081ceb794a3b51f5bbbe
  1.7-3-Stable-Ember: e0a0e3ea480892261fff00f1e9f878ec
