---
config:
  app_name: joomla-cms
  check_file: media/system/js/switcher.js
sigs:
  1.7-3-Stable-Ember: 4a41bce5f8b49e1f51e0b5b3250051a7
  1.7-3-Stable-Ember: d824a02522aa08420533546c78c9fc11
  1.7-3-Stable-Ember: 22b18ebdc4eb5083d8927035037fbb1d
  1.7-3-Stable-Ember: b944dd5b3e18f44f3ea31344c3bf0100
  1.7-3-Stable-Ember: 0e372a2704b40d952b8b1827f386baf0
  1.7-3-Stable-Ember: 21abfd849643a3cba9236a3e7457fc2b
  1.7-3-Stable-Ember: d50712c7fbe04058315f6411c988ce22
  1.7-3-Stable-Ember: 5f2d09898aaf7d86cd988a41ae852c40
  1.7-3-Stable-Ember: 73891ceff94a780897ac3631fcddfc03
  1.7-3-Stable-Ember: d5370e8be821eaf3b7a76803a52bae17
  1.7-3-Stable-Ember: 30cdfbc9695065af0d735c1692f28e9a
  1.7-3-Stable-Ember: f4d3022e31d3a9a3bab04f73833a92bd
  1.7-3-Stable-Ember: f2e9d23823532f1e2b77318611ff21ae
  1.7-3-Stable-Ember: 940e3924da3cf4320695204e8789a4ab
  1.7-3-Stable-Ember: 037f1b2de44df893cb9636052930d8eb
  1.7-3-Stable-Ember: 75b84e4351458d5e065c8e7b2be9cf51
  1.7-3-Stable-Ember: 3259c1205e2d1a031f1ed5dd00106c8e
  1.7-3-Stable-Ember: cff1725ec55221b240cc05d28e780366
  1.7-3-Stable-Ember: 2fe895ed74bc23bdf47de190a2877ef2
  1.7-3-Stable-Ember: fdad78b95677a90bbc975592fef2a2ac
  1.7-3-Stable-Ember: 59f8577146a2c08cf870d973bcdbad8b
  1.7-3-Stable-Ember: 5748623821318819a72020435e11eb56
  1.7-3-Stable-Ember: da119ae76ae7647f21fa4a976d0adaa9
  1.7-3-Stable-Ember: fea76b7322a84f1b71f8da8a904419b0
  1.7-3-Stable-Ember: 129a165ec2fd9b01c6a3270b94e5a9d0
  1.7-3-Stable-Ember: 5f2d09898aaf7d86cd988a41ae852c40
  1.7-3-Stable-Ember: 86a884cc7a420b349d2cf8896f58fc32
