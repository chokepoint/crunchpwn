---
config:
  app_name: joomla-cms
  check_file: components/com_media/assets/popup-imagemanager.js
sigs:
  1.7-3-Stable-Ember: 3ae14de6e73c659bd3e643ce5765e875
  1.7-3-Stable-Ember: 8cb887ea8c63ca9095aa6262e698180f
  1.7-3-Stable-Ember: 60d99b230c5e75cb5b21541eaf444925
  1.7-3-Stable-Ember: e00872a69cadb4241563e3ac98cbd4d5
  1.7-3-Stable-Ember: b5642861dc2d048ac376e9b309ce878b
  1.7-3-Stable-Ember: 57d570c295712ed2fc389e473f85b085
  1.7-3-Stable-Ember: d85630aef4e25cf83f8b15c904d78b43
  1.7-3-Stable-Ember: 78b7b04b4f2417e8be47ace9e8b596f9
  1.7-3-Stable-Ember: 0f2814208885b731b9808d83abb0d366
  1.7-3-Stable-Ember: b8b5f1d4e762628f66e9f66844c92c1e
  1.7-3-Stable-Ember: e00872a69cadb4241563e3ac98cbd4d5
  1.7-3-Stable-Ember: 3103dae5b83cb02f4b6e7c7bd885dc6e
  1.7-3-Stable-Ember: 6af68d801d9aa019795c16f29a30ddf2
  1.7-3-Stable-Ember: f81a311d2e981ec45d138c620b2233b0
  1.7-3-Stable-Ember: c54f42ffd338b12764f6a71d111a712d
  1.7-3-Stable-Ember: c625696dc8b90200239944777cf113d9
  1.7-3-Stable-Ember: 465051847961923a6d13a8c14520731c
  1.7-3-Stable-Ember: 6694368eece25b3a1d3e4847a476ac1d
  1.7-3-Stable-Ember: c625696dc8b90200239944777cf113d9
  1.7-3-Stable-Ember: 97ffa1b2329b8ec7eae0d522513858e5
  1.7-3-Stable-Ember: 116796ae6e97a915243101be29b9353d
  1.7-3-Stable-Ember: cbdd43d7a3c5c171e04953d068679eff
  1.7-3-Stable-Ember: 460438d4311f7c75f84aab80d5f34e35
  1.7-3-Stable-Ember: 6c286c9c968f2ee3e036c463fafbcca2
  1.7-3-Stable-Ember: 4a03048f3e80a6015ef68667377cff6e
  1.7-3-Stable-Ember: 8bf43d0ac3ee9b35a63f7f4aac1051eb
