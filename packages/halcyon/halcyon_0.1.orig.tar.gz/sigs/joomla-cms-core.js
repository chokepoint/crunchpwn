---
config:
  app_name: joomla-cms
  check_file: media/system/js/core.js
sigs:
  3.0-0_alpha2-Alpha-Ember: 3db288bf3db8e187a78c75b96cd0199d
  1.7-3-Stable-Ember: 104cf9d1b07d6fa8e37400da2ba0085d
  1.7-3-Stable-Ember: 2552dbe8928e6be435a1411eee669833
  1.7-3-Stable-Ember: e2da4df75702ee4bae71d0fe67d83918
  1.7-3-Stable-Ember: 6dd47ab724a4240e4399403ee3ba6705
  1.7-3-Stable-Ember: 9500c07e5698b99b8a084d0d9f50e6a3
  1.7-3-Stable-Ember: f3eb7b99763c30dd8cfefb71ed551d10
  1.7-3-Stable-Ember: daf043edb9e09b0882399091076880c8
  1.7-3-Stable-Ember: 5257add9eda2d0f15c2f0420f02a2516
  1.7-3-Stable-Ember: 8d0191f55f952a8a06692c2de43d1c54
  1.7-3-Stable-Ember: 2fe56a701779b7424549885eb7b31d39
  1.7-3-Stable-Ember: 03f53c4db2b8169144cb14fc9a1dac21
  1.7-3-Stable-Ember: d28e68db0945e4935d40f3e89d357acb
  3.0-0_alpha2-Alpha-Ember: cfc89c60591594302a8020748abd09f2
  1.7-3-Stable-Ember: 993a120d5fae096c047e87b4bc2d51a5
  1.7-3-Stable-Ember: a18625bb013e9952d11227a7e1dfd429
  1.7-3-Stable-Ember: 8e42cbc1af2ff8d189a04093e5c08d56
  1.7-3-Stable-Ember: 7b5f38d1e6ed4e46868ab9ec953c0746
  2.5-2-Stable-Ember: 4b59c964036a5a6ba36d4cfa34968c2a
  1.7-3-Stable-Ember: ac93187ee280804fc27bdaeda1e3c2b1
  1.7-3-Stable-Ember: 12c981b5b906015c60fde0130f51c4fd
  1.7-3-Stable-Ember: 301239b824f24ff2f9f8e02db2f92543
  1.7-3-Stable-Ember: 9a9aa5d20511898204370a880c425965
  1.7-3-Stable-Ember: 0c7bae15c5895a587f17defe80cdf0cf
  1.7-3-Stable-Ember: 758e49b22d55274ed3cc22bf83b68834
  1.7-3-Stable-Ember: 960457b0a9bc9bf3c2019ed1e8dee634
  1.7-3-Stable-Ember: b131aca0deee34f05007c2f045f8ff60
  2.5-1-Stable-Ember: d0d562e51d94cd8cf1136c6e4d3e800c
