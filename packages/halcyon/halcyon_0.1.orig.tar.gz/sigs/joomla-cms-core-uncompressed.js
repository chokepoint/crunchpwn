---
config:
  app_name: joomla-cms
  check_file: media/system/js/core-uncompressed.js
sigs:
  1.7-3-Stable-Ember: 301239b824f24ff2f9f8e02db2f92543
  1.7-3-Stable-Ember: e2da4df75702ee4bae71d0fe67d83918
  3.0-0_alpha2-Alpha-Ember: 44cf073e680a5fc3cce4bc85a4aafac6
  1.7-3-Stable-Ember: 104cf9d1b07d6fa8e37400da2ba0085d
  1.7-3-Stable-Ember: a3be108908ef707313341a34c7c87e20
  1.7-3-Stable-Ember: c45f3c3955eaf030ad78e2ecb8c18b3c
  1.7-3-Stable-Ember: 961eeff7bb2ce99bbbaa386a1e2a7fff
  1.7-3-Stable-Ember: 14d544da3ef32032cb55ca0474261f33
  1.7-3-Stable-Ember: bf44880df50a03748fc9e25fc84b125b
  1.7-3-Stable-Ember: 2fe56a701779b7424549885eb7b31d39
  1.7-3-Stable-Ember: b7026482c42a944b44cbbd45dfc4ee69
  1.7-3-Stable-Ember: 03f53c4db2b8169144cb14fc9a1dac21
  1.7-3-Stable-Ember: d28e68db0945e4935d40f3e89d357acb
  3.0-0_alpha2-Alpha-Ember: b70e5bef6185570a803e090d76795b6d
  1.7-3-Stable-Ember: 6738f18c878edafeca86c1d121e759fe
  1.7-3-Stable-Ember: a18625bb013e9952d11227a7e1dfd429
  1.7-3-Stable-Ember: 3819bc742ef9bbcd6fac5e2aeaefb977
  1.7-3-Stable-Ember: 7b5f38d1e6ed4e46868ab9ec953c0746
  2.5-2-Stable-Ember: 97d77e9f522ff8418445b4cb82dd4940
  2.5-0_Beta2-Beta-Ember: 9ffd9b43e20a009a6d0fb7c0b472c36a
  1.7-3-Stable-Ember: 9a9aa5d20511898204370a880c425965
  1.7-3-Stable-Ember: eeee43c0db9463b28bbcf691d050c18a
  1.7-3-Stable-Ember: eb93600d0c8014885c05faa94d02372f
  1.7-3-Stable-Ember: 960457b0a9bc9bf3c2019ed1e8dee634
  1.7-3-Stable-Ember: 984ddfc9460ed0b3284dbdcb2ee1ff48
  2.5-1-Stable-Ember: 8099b2005431daa745a3f0893af519e2
