---
config:
  app_name: joomla-cms
  check_file: media/system/js/combobox.js
sigs:
  1.7-3-Stable-Ember: 33752d41e96682521a5e64399e8fb5c1
  1.7-3-Stable-Ember: c72f2bf7097a2798dffa61c8524c22d5
  1.7-3-Stable-Ember: 5538a80d0e2022142be7fecbe8bd3809
  1.7-3-Stable-Ember: 939d52769e5b2ba9484852ccac702cc5
  1.7-3-Stable-Ember: 7642db9f82160930f141407e874e4b6f
  1.7-3-Stable-Ember: 6ab958a3401b714836e64255df8a355a
  1.7-3-Stable-Ember: 8e1599d7a5ec486451dd982ec915d085
  1.7-3-Stable-Ember: 50bf2189c1d3f61d37f073bb4d7cc4ab
  1.7-3-Stable-Ember: f295fc2912c8b3b512ac6b4377cdf32b
  1.7-3-Stable-Ember: 57153c70ee67c67f897d3e3d17bea181
  1.7-3-Stable-Ember: 9b281fcf5d66c6fb7d2b033d4d0e5f88
  1.7-3-Stable-Ember: 9e966dc6ddc7522251a527b1b69e928e
  1.7-3-Stable-Ember: e4c9c9448d4902b8e34c3d0ae771955c
  1.7-3-Stable-Ember: 8dde8beba4c2ed9994524e0844d58958
  1.7-3-Stable-Ember: 0e148ce69b665e81c8c50c30dede7ce3
  1.7-3-Stable-Ember: 8b21344c5b0f7c108a55796d86b17057
  1.7-3-Stable-Ember: eca0cf3838b3414de77108322d7e57f4
  1.7-3-Stable-Ember: baddb15712cb0a1826377019f926750d
  1.7-3-Stable-Ember: 62f6129f908d35a15c0f352ece59dc92
  1.7-3-Stable-Ember: cee11d965ec379759ca5d6f2f439124f
