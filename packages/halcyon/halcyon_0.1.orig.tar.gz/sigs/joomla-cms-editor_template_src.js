---
config:
  app_name: joomla-cms
  check_file: plugins/editors/tinymce/jscripts/tiny_mce/themes/advanced/editor_template_src.js
sigs:
  1.7-3-Stable-Ember: ee4d1786f34637a929459793746e46c2
  1.7-3-Stable-Ember: 917e44b29a5ac99faf2e11f76bd012d0
  1.7-3-Stable-Ember: 2047b1faea9a118a8ba2b98b2ec52186
  1.7-3-Stable-Ember: 46f4d195a595a43f35bfaf30357b243c
  1.7-3-Stable-Ember: dca7706c1e2435232c39bdf57ec32fda
  1.7-3-Stable-Ember: 39c1f6252a6b32271c4fee67b991a0da
  1.7-3-Stable-Ember: de2d5aa3f5f7455c28e5eba9c17ede3d
  1.7-3-Stable-Ember: 53343744671e8c3abca275429f87eefd
  1.7-3-Stable-Ember: 89919316140a2fec2caba5d56002e0c0
  1.7-3-Stable-Ember: 37c34842a10892b11bd0466f4d32ef7a
  1.7-3-Stable-Ember: 73051a8b9b0222b230fd0e89ef393f19
  1.7-3-Stable-Ember: c51fc1cb4878c66422062071b0dccd1a
  1.7-3-Stable-Ember: b0411e1b536edfb6bfb0299e841ce84a
  1.7-3-Stable-Ember: 77c1bbf3d09e05b12dca8fe37bb63405
  1.7-3-Stable-Ember: 39c1f6252a6b32271c4fee67b991a0da
  1.7-3-Stable-Ember: 1f4cebfd2bda933a76b14018a9c6c431
  1.7-3-Stable-Ember: 73051a8b9b0222b230fd0e89ef393f19
  1.7-3-Stable-Ember: 3430af5778236d0d1669178f4e5d2431
  1.7-3-Stable-Ember: c7a7103e1d7c9e133b9f5ed522040134
