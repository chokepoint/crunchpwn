---
config:
  app_name: joomla-cms
  check_file: plugins/editors/tinymce/jscripts/tiny_mce/plugins/fullscreen/editor_plugin_src.js
sigs:
  1.7-3-Stable-Ember: ed4c9a6d56f866a68bd2254344bad10a
  1.7-3-Stable-Ember: 93a2b9ae2187b54dec773caa4fc70579
  1.7-3-Stable-Ember: 451c075b103122049b29e5d74a6c86bd
  1.7-3-Stable-Ember: a54cd3cd08af8d256f91dee7fc74a2d9
  1.7-3-Stable-Ember: eae54df7b62c24a6274ceaf1eae27878
  1.7-3-Stable-Ember: eae54df7b62c24a6274ceaf1eae27878
  1.7-3-Stable-Ember: aefd8673a10a2c83e0cc9f5a39e98c55
  1.7-3-Stable-Ember: 1ccf5b4b80b3857ae7e1cac837f34cf0
  1.7-3-Stable-Ember: d6eb4b2eda75b1f87355ce7c474e7fdf
  1.7-3-Stable-Ember: dd36ed3a9bbfdec2ad0ef2e2dbd2ae37
  1.7-3-Stable-Ember: 942b109f8566681072e84696fe43254c
  1.7-3-Stable-Ember: c490618ef1882a096c0eaa126efdc264
  1.7-3-Stable-Ember: f4eb8b9ba990300401772d91b907ebf3
  1.7-3-Stable-Ember: d6eb4b2eda75b1f87355ce7c474e7fdf
  1.7-3-Stable-Ember: d36882ed967fcf1f2b7760eb7c0f6ebb
  1.7-3-Stable-Ember: 7cbbd3518c26ffb59d8d2602160a9289
  1.7-3-Stable-Ember: 942b109f8566681072e84696fe43254c
  1.7-3-Stable-Ember: 942b109f8566681072e84696fe43254c
