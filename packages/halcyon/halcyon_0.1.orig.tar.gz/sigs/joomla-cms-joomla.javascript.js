---
config:
  app_name: joomla-cms
  check_file: includes/js/joomla.javascript.js
sigs:
  1.7-3-Stable-Ember: 03b02bf92d02f77e66510cca310b275d
  1.7-3-Stable-Ember: 9e77b29b07a552c5ff5b567ba4fa59c5
  1.7-3-Stable-Ember: 18dc2591b139a4f9895de9a7ebdee543
  1.7-3-Stable-Ember: 94f8cbce0ebe0e6de53597fea98d0252
  1.7-3-Stable-Ember: 1cf092193e36a42d4fd44a509ef9ef8c
  1.7-3-Stable-Ember: fe9040138a1e7324c01bbcba7a1cbdd3
  1.7-3-Stable-Ember: 119918b41de2f9cb0dcfafad4581e678
  1.7-3-Stable-Ember: 6890730f01a70f85766470b139919d7d
  1.7-3-Stable-Ember: 962e0309538bea2b00ac2fa0bdd0988e
  1.7-3-Stable-Ember: f27318d5c5bd6bd06fe4e95c68eb1029
  1.7-3-Stable-Ember: 57f1a89cbc11032e6734562dfbcaf5b2
  1.7-3-Stable-Ember: 57c33228a852fba604379a630dbf2f44
  1.7-3-Stable-Ember: aaa8605f7a96b4712fa341c6b3f65463
  1.7-3-Stable-Ember: 87b8954967f72ddd4d2c6947baceb966
  1.7-3-Stable-Ember: 962dadbc8a3787aa95bec5be41e0ef0d
  1.7-3-Stable-Ember: d8524ae42f684a33742c6d3420ceedaa
  1.7-3-Stable-Ember: 2c2080b6d2b075fd6db83c009731ba36
  1.7-3-Stable-Ember: 37075e0cefabd6325cb334b8375a513c
  1.7-3-Stable-Ember: 9170d0a245497ccf0efec4ac5136010f
  1.7-3-Stable-Ember: 0038ecdccdb546892c04f89fe713b0bf
  1.7-3-Stable-Ember: d7b7864901c4b49c0d87f3af530d28a2
  1.7-3-Stable-Ember: 37b28ba731e48e4dbb45b0a1b9095da9
  1.7-3-Stable-Ember: fe098937789b601ae846f07296d34cbf
  1.7-3-Stable-Ember: 57c05b17e362c5e33acbb454377764cb
  1.7-3-Stable-Ember: 822f5501254b66c9a8dbe1e2b0901561
