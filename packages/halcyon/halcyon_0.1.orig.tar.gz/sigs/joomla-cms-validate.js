---
config:
  app_name: joomla-cms
  check_file: media/system/js/validate.js
sigs:
  1.7-3-Stable-Ember: ae2e50fa93b526e8d23fbb5f35a3fbc9
  1.7-3-Stable-Ember: e8f34c76abf2a4bdb8d3daea1094abcd
  1.7-3-Stable-Ember: 9a369814240e752fe7e4d4241755e7f1
  1.7-3-Stable-Ember: 8a555e5ab15ced1f5e0ddcb581333093
  1.7-3-Stable-Ember: 1e0dc8c0e3f62ce1fce3ee366c6fd620
  1.7-3-Stable-Ember: 2acc1e8e29ee21a989d8fa8895c0cd92
  : f2d7b5e98f6a7c15aa94feb7d3a46c5e
  1.7-3-Stable-Ember: a27e577b74498099b627659fbaf6580e
  1.7-3-Stable-Ember: 724c1007fcbb852dddd7a9cd9ea74429
  1.7-3-Stable-Ember: b212a6175adad3c94823efdddd0c35e5
  1.7-3-Stable-Ember: a22e688e292eee7ebf92dcab77ff6369
  1.7-3-Stable-Ember: e7618653960bf0eb18d37f16f9232955
  1.7-3-Stable-Ember: cbf0382d4dd06a34a748122ca671522c
  1.7-3-Stable-Ember: 5a2ab57d502db26ca775c6da2813d47e
  1.7-3-Stable-Ember: 4be7d605a42ef3e9a1b2bcd490d2ae22
  1.7-3-Stable-Ember: 3907fe4995af96a1ad3f519954e10b24
  1.7-3-Stable-Ember: fdf4439f4ddc61536ad08733be04accf
  1.7-3-Stable-Ember: 6b97ab2df4b23ac908b585cf7e495ebd
  1.7-3-Stable-Ember: f5ae2571cc4ad48b8f24e7ce6fd83c55
  1.7-3-Stable-Ember: c85a6004a2317cb61a2ddc00f8b5e28e
  1.7-3-Stable-Ember: f8e248b7c4e7c038ec76ae657afd2f50
  1.7-3-Stable-Ember: 37506fcb6cc356f9908cef266d436879
  1.7-3-Stable-Ember: 219d4593eff79f6f3385ec0cfc718f6a
  1.7-3-Stable-Ember: 1ffd563685cbbf4cfb39f7dc5f2f4941
  1.7-3-Stable-Ember: aa5a30e8273fcd6e447b72c98531ffe0
  1.7-3-Stable-Ember: f082d016245fce5783393aa8c65f5675
  1.7-3-Stable-Ember: f4c6c283a9f6106a07f902489d598ac2
  1.7-3-Stable-Ember: 6e78e23d91d418ccb5460e4f813e3dbc
  1.7-3-Stable-Ember: ca5ff9e01de464bc9c079cd287d1e30a
  1.7-3-Stable-Ember: c06445366945064c97888346f19225d6
  1.7-3-Stable-Ember: 4e24894bc02173ec11a0bb6df814f1f7
