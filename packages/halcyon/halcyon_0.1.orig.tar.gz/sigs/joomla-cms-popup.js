---
config:
  app_name: joomla-cms
  check_file: includes/js/joomla/popup.js
sigs:
  1.7-3-Stable-Ember: da8eae9f1746489cd4ae379bd27833a0
  1.7-3-Stable-Ember: f853429f7859dd0c421f1798152e097b
  1.7-3-Stable-Ember: 408c5ad7802eed14995193759f67d92a
  1.7-3-Stable-Ember: 0260b826bc5eff0029e6790af1918a97
  1.7-3-Stable-Ember: 8a322c5676349dcc830ca4c619040db1
  1.7-3-Stable-Ember: 469bf9a650dd0c4bda4f29c51938ae71
  1.7-3-Stable-Ember: bee79035d82d65dbd595cd3a9dfefe75
  1.7-3-Stable-Ember: 07d46eb19688aff54d72674739a38ae0
  1.7-3-Stable-Ember: d53c0fd26f1ec0551ac1380c0f88dba0
  1.7-3-Stable-Ember: 9821e66218c152168a2b03d749671ed2
  1.7-3-Stable-Ember: 969df686aa87123d703d3b303f134cbb
  1.7-3-Stable-Ember: 59ab3b5d79f011e2100441236021690e
  1.7-3-Stable-Ember: 523b041df0d7ad20511b8f5e88d7a04c
  1.7-3-Stable-Ember: bff2ad0e806e81f72e6da3df60fc33f8
  1.7-3-Stable-Ember: a7b4f046830974fd490745c0c7c8906f
  1.7-3-Stable-Ember: 0d7b18869e495a1693e6654a278a7597
  1.7-3-Stable-Ember: de2d7d405a4498a2d7bcadccb6c21866
  1.7-3-Stable-Ember: 3434349fe6fa82d2640193e28cf56333
  1.7-3-Stable-Ember: 969df686aa87123d703d3b303f134cbb
  1.7-3-Stable-Ember: 49814832bcdeb67c4c47265d95e7f931
  1.7-3-Stable-Ember: 8bc39fca51c799d15d79306be2373a30
  1.7-3-Stable-Ember: 469bf9a650dd0c4bda4f29c51938ae71
