?package(beleth):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="beleth" command="/usr/bin/beleth"
