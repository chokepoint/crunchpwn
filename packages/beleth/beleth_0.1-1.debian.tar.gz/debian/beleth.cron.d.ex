#
# Regular cron jobs for the beleth package
#
0 4	* * *	root	[ -x /usr/bin/beleth_maintenance ] && /usr/bin/beleth_maintenance
