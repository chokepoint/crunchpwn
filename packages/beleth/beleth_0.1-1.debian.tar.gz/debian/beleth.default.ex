# Defaults for beleth initscript
# sourced by /etc/init.d/beleth
# installed at /etc/default/beleth by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
