#include <config.h>
#include <unilib/output.h>

#include "libunirainbow.h"

char *x86_alpha_encode(const char *shellcode, size_t shellcode_len, const char *banned, int flags, size_t *ls) {
	ERR("NYI");
	return NULL;
}
