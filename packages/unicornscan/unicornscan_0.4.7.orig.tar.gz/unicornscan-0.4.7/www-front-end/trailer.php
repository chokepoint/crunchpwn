<?php

	print <<<EOF
 </body>
</html>

EOF;

?>
