#ifndef PROTO_SSH_H
#define PROTO_SSH_H
#include "proto-banner1.h"

extern const struct ProtocolParserStream banner_ssh;

#endif
