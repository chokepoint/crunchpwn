#ifndef PROTO_SSL_H
#define PROTO_SSL_H
#include "proto-banner1.h"

extern const struct ProtocolParserStream banner_ssl;

#endif
