#ifndef IN_BINARY_H
#define IN_BINARY_H
struct Masscan;
void
convert_binary_files(struct Masscan *masscan, int arg_first, int arg_max, char *argv[]);

#endif

