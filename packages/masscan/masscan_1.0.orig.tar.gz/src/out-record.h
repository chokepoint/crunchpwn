#ifndef OUT_RECORD_H
#define OUT_RECORD_H

enum OutputRecordType {
    Out_Open = 1,
    Out_Closed = 2,
    Out_Banner = 5,
};
#endif
