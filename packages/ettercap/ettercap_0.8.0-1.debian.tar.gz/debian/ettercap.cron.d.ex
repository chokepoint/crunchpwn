#
# Regular cron jobs for the ettercap package
#
0 4	* * *	root	[ -x /usr/bin/ettercap_maintenance ] && /usr/bin/ettercap_maintenance
