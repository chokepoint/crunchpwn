?package(ettercap):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="ettercap" command="/usr/bin/ettercap"
