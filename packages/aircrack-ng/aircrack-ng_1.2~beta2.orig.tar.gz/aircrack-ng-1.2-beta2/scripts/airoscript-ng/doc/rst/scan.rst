Scan
-----

Scanning is a simple menu, just asking for encription (wich can be set up to be anything (default)) and channel (hoping by default).

