Autopwn
--------

Autopwn function will try each available (and enabled) attack against every network available.
You can specify essid filters, and change enabled attacks in advanced airoscript-ng configuration, have a look at main usage for argument.
