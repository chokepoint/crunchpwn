?package(aircrack-ng):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="aircrack-ng" command="/usr/bin/aircrack-ng"
