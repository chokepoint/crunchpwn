#
# Regular cron jobs for the aircrack-ng package
#
0 4	* * *	root	[ -x /usr/bin/aircrack-ng_maintenance ] && /usr/bin/aircrack-ng_maintenance
