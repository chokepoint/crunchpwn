# Defaults for aircrack-ng initscript
# sourced by /etc/init.d/aircrack-ng
# installed at /etc/default/aircrack-ng by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
