?package(medusa):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="medusa" command="/usr/bin/medusa"
