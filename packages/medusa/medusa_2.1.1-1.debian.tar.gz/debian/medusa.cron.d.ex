#
# Regular cron jobs for the medusa package
#
0 4	* * *	root	[ -x /usr/bin/medusa_maintenance ] && /usr/bin/medusa_maintenance
