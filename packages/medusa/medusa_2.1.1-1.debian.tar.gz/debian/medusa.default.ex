# Defaults for medusa initscript
# sourced by /etc/init.d/medusa
# installed at /etc/default/medusa by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
